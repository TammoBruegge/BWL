import matplotlib.pyplot as plt

def energy_balance():
    values2 = []  # Initial leere Arrays für die zu plottenden Werte.
    time = []

    user_inputs = climate_model.get_user_inputs()
    y0 = user_inputs[0]

    # Laufvariablen initialisieren.
    i = values.t0  # i auf t0 setzen
    s = y0  # s auf y(t0) setzen

    # Timeloop ausführen.
    while i <= values.T:
        s = time_discretization.euler(climate_model.ableitung_y, values.delta_t, s,
                                      0)  # nun ersetze s durch y(tk+1), wenn s vorher y(tk) war
        values2.append(s)  # Werte dem Array hinzufügen
        time.append(i)
        i += values.delta_t  # einen Zeitschritt weiter gehen

    # Graph plotten
    plt.plot(time, values2)
    plt.xlabel('Zeitpunkt in Sekunden')
    plt.ylabel('Temperatur in Kelvin')
    plt.ticklabel_format(useOffset=False)  # Genaueres Anzeigen großes Zahlen
    plt.show()


def pred_prey():
    # values_pred_prey = [[], []]
    values_predator = []  # Initial leere Arrays für die zu plottenden Werte.
    values_prey = []
    time = []

    user_inputs = climate_model.get_user_inputs()
    x0 = user_inputs[0]
    y0 = user_inputs[1]

    # Laufvariablen initialisieren.
    i = values.t0  # i auf t0 setzen
    s_prey = x0  # s_prey ist Anfangsbestand an Gejagten
    s_predator = y0  # s_predator ist Anfangsbestand an Jägern
    s_prey_temp = s_prey # Platzhalter für Berechnung damit beide Bestände gleichzeitign inkrementiert werden
    s_predator_temp = s_predator # Platzhalter für Berechnung damit beide Bestände gleichzeitign inkrementiert werden

    # Timeloop ausführen.
    while i <= values.T:
        s_predator_temp = time_discretization.euler(climate_model.ableitung_y, values.delta_t, s_predator, s_prey)  # nun ersetze s_predator_temp durch y(tk+1), wenn s vorher y(tk) war
        values_predator.append(s_predator_temp)  # Wert dem Array hinzufügen
        # values_pred_prey[0].append(s_predator_temp)

        s_prey_temp = time_discretization.euler(climate_model.ableitung_x, values.delta_t, s_prey, s_predator)  # nun ersetze s_prey_temp durch x(tk+1), wenn s vorher x(tk) war
        values_prey.append(s_prey_temp)  # Wert dem Array hinzufügen
        # values_pred_prey[1].append(s_prey_temp)

        time.append(i) # Wert dem Array hinzufügen

        s_predator = s_predator_temp # gleichzeitiges Ändern beides Bestände, damit nicht die Änderung eines Bestandes die Berechnung des anderen beeinflusst
        s_prey = s_prey_temp

        i += values.delta_t  # einen Zeitschritt weiter gehen

    # Graph plotten
    plt.plot(time, values_prey, 'b', time, values_predator, 'r') # Prey sind blau, Predator rot
    # plt.plot(time, values_pred_prey[0], 'b', values_pred_prey[1], 'r') # Prey sind blau, Predator rot
    plt.xlabel('Zeitpunkt in Sekunden')
    plt.ylabel('Bestand in Anzahl Tiere')
    plt.ticklabel_format(useOffset=False) # Genaueres Anzeigen großes Zahlen
    plt.show()


# Main-Methode, welche zuerst User-Input für alle Variablen, welche für das Lösen der ODE benötigt werden, liest.
if __name__ == '__main__':
    model = input("Which model do you wanna use? (a for Energy Balance Model, b for Predator Prey Model): ")
    method = input("Which model do you wanna use? (a for Euler, b for Improved Euler): ")
    if method == "a":
        from Serie2 import euler_method as time_discretization
    if method == "b":
        from Serie2 import improved_euler_method as time_discretization
    if model == "a":
        from Serie2 import energy_balance_model as climate_model, values_energy_balance_model as values
        energy_balance()
    if model == "b":
        from Serie2 import predator_prey_model as climate_model, values_predator_prey_model as values
        pred_prey()
