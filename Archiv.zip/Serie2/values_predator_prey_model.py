t0 = 0  # Anfangszeit
T = 45  # Endzeit
n = 4500 # Anzahl Zeitschritte
delta_t = (T - t0) / n  # Schrittgröße