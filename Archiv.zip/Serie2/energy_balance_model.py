"""
# Gegebene Parameter
alpha = 0.3  # Albedoeffekt
e = 0.62  # Emissitivität
y0 = 23 # Startwert
"""

# Gegebene Konstanten, welche nicht vom Nutzer verändert werden sollen.
C = 9.96 * (10 ** 6)  # thermal coupling constant
phi = 5.67 * (10 ** -8)  # Boltzmannnkonstante
sc = 1367.0  # Solarkonstante

def get_user_inputs():
    global y0
    global alpha
    global e
    y0 = float(input("Enter the starting temperature: "))
    alpha = float(input("Enter the emissivity: "))
    e = float(input("Enter the albedo effect: "))
    return [y0]

# Die Ableitung von y bilden nach den Vorgaben der Aufgabe.
def ableitung_y(s, parameters):
    c1 = 1 / (4 * C) # Berechnen von c1 und c2 nach vorgegebenen Regeln.
    c2 = (phi * e) / C
    return c1 * sc * (1 - alpha) - c2 * (s ** 4) # Berechnen der Ableitung nach vorgegebener Art.