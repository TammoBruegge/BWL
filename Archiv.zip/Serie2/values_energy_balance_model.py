t0 = 0  # Anfangszeit
T = 450000000  # Endzeit #5
n = 450000 # Anzahl Zeitschritte #4
delta_t = (T - t0) / n  # Schrittgröße