

boxes = 100

a = 2.0
b = 3.0
g = 1.0
d = 3.0
l = 1.0
m = 1.0
e = 10**-4
kappa = 0.01

h = 1 / boxes

delta_t = kappa / 10 # Schrittgröße