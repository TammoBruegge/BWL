from Serie1 import energy_balance_model as climate_model, values


# Den Wert für y zum Zeitpunkt t bestimmen, wenn y zum Zeitpunkt t - delta_t s war
def y(s):
    return s + values.delta_t * climate_model.ableitung_y(s)  # s = y(t - delta_t) = y(t) für ableitung_y