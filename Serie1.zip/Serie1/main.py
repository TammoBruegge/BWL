import matplotlib.pyplot as plt
from Serie1 import energy_balance_model as climate_model, euler_method as time_discretization, values

values2 = []
time = []


i = values.t0  # i auf t0 setzen
s = climate_model.y0  # s auf y(t0) setzen
while i <= values.T:
    s = time_discretization.y(s)  # nun ersetze s durch y(tk+1), wenn s vorher y(tk) war
    values2.append(s)  # Werte Wert dem Array hinzufügen
    time.append(i)
    i += values.delta_t  # einen Zeitschritt weiter gehen

plt.plot(time, values2)
plt.xlabel('Zeitpunkt in Sekunden')
plt.ylabel('Temperatur in Kelvin')
plt.ticklabel_format(useOffset=False)
plt.show()
