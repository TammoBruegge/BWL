t0 = 0.0  # Anfangszeit
T = 40000000.0  # Endzeit
n = 1000000  # Anzahl Zeitschritte
delta_t = T / n  # Schrittgröße