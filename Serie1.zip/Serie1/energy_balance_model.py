# Gegebene Parameter
alpha = 0.3  # Albedoeffekt
C = 9.96 * (10 ** 6)  # thermal coupling constant
e = 0.62  # Emissitivität
phi = 5.67 * (10 ** -8)  # Boltzmannnkonstante
S = 1367.0  # Solarkonstante
y0 = 23.0  # y(t0) -> Anfangstemperatur


c1 = 1 / (4 * C)
c2 = (phi * e) / C


# Die Ableitung von y bilden, s ist hier y(t), da s in y(t, s) gerade y(t - delta_t) war
def ableitung_y(s):
    return c1 * S * (1 - alpha) - c2 * (s ** 4)